import offers from '@/data/offers.json';

export function loadOffers() {
  return offers.map((offer) => ({
    id: offer.externalId,

    provider: offer.provider,

    hotelName: offer.hotelName,

    destinationCountry: offer.country,

    destinationRegion: offer.region,

    departureAirport: offer.departureAirport,

    boardType: offer.boardType,

    nights: offer.nights,

    price: offer.price,

    pricePerDay:
      offer.nights > 0
        ? Math.round(offer.price / offer.nights)
        : offer.price,

    stars: offer.stars,

    rating: offer.rating,

    imageUrl: offer.imageUrl,

    deepLink: offer.deepLink,

    departureWindowStart: '',

    departureWindowEnd: '',

    valueScore: 0,

    flexibilityScore: 0,
  }));
}