export interface TravelOffer {
  id: string;
  provider: string;
  hotelName: string;
  destinationCountry: string;
  destinationRegion?: string;
  departureAirport?: string;
  boardType?: string;
  nights: number;
  price: number;
  pricePerDay: number;
  stars?: number;
  rating?: number;
  imageUrl: string;
  deepLink: string;
  departureWindowStart?: string;
  departureWindowEnd?: string;
  valueScore?: number;
  flexibilityScore?: number;
  isBestDeal?: boolean;
  isCheapestProvider?: boolean;
}

export interface SearchParams {
  country?: string;
  region?: string;
  budgetMin?: number;
  budgetMax?: number;
  nightsMin?: number;
  nightsMax?: number;
  boardTypes?: string[];
  adults?: number;
  children?: number;
  rooms?: number;
  departureStart?: string;
  departureEnd?: string;
  departureAirport?: string;
  stars?: number;
  sort?: string;
}
