const fs = require('node:fs');
const path = require('node:path');
const { XMLParser } = require('fast-xml-parser');

const xmlPath = path.join(process.cwd(), 'data', 'productfeed.xml');
const outputPath = path.join(process.cwd(), 'data', 'offers.json');

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '',
});

const xml = fs.readFileSync(xmlPath, 'utf8');
const parsed = parser.parse(xml);

const products = Array.isArray(parsed.products.product)
  ? parsed.products.product
  : [parsed.products.product];

function getProperty(product, name) {
  const properties = product.properties?.property;

  if (!properties) return '';

  const list = Array.isArray(properties) ? properties : [properties];

  const found = list.find((p) => p.name === name);

  return found ? found.value : '';
}

const offers = products.map((product) => ({
  externalId: String(product.ID),

  hotelName: product.name,

  provider: 'Corendon',

  price: Number(product.price?.['#text'] ?? product.price),

  currency: product.price?.currency || 'EUR',

  deepLink: product.URL,

  imageUrl:
    product.images?.image ||
    getProperty(product, 'imageURL_large') ||
    '',

  nights: Number(getProperty(product, 'duration')),

  stars: Number(getProperty(product, 'stars')),

  rating: Number(
    String(getProperty(product, 'rating') || '0').replace(',', '.')
  ),

  departureAirport: getProperty(product, 'iataDeparture'),

  boardType: getProperty(product, 'serviceType'),

  country: getProperty(product, 'country'),

  region: getProperty(product, 'region'),
}));

fs.writeFileSync(outputPath, JSON.stringify(offers, null, 2));

console.log(`✔ ${offers.length} aanbiedingen geïmporteerd`);